
package net.mcreator.minecraftmod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.entity.player.PlayerEntity;

import net.mcreator.minecraftmod.procedures.LoblinePickaxeItemIsCraftedsmeltedProcedure;
import net.mcreator.minecraftmod.itemgroup.LoblineTabItemGroup;
import net.mcreator.minecraftmod.MinecraftmodModElements;

import java.util.Map;
import java.util.HashMap;

@MinecraftmodModElements.ModElement.Tag
public class LoblinePickaxeItem extends MinecraftmodModElements.ModElement {
	@ObjectHolder("minecraftmod:lobline_pickaxe")
	public static final Item block = null;
	public LoblinePickaxeItem(MinecraftmodModElements instance) {
		super(instance, 10);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 290;
			}

			public float getEfficiency() {
				return 6f;
			}

			public float getAttackDamage() {
				return 2f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 10;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(LoblineItem.block, (int) (1)));
			}
		}, 1, -3f, new Item.Properties().group(LoblineTabItemGroup.tab)) {
			@Override
			public void onCreated(ItemStack itemstack, World world, PlayerEntity entity) {
				super.onCreated(itemstack, world, entity);
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("itemstack", itemstack);
					LoblinePickaxeItemIsCraftedsmeltedProcedure.executeProcedure($_dependencies);
				}
			}
		}.setRegistryName("lobline_pickaxe"));
	}
}
