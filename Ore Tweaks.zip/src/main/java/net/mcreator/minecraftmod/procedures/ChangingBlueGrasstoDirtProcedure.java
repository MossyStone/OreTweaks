package net.mcreator.minecraftmod.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;

import net.mcreator.minecraftmod.block.BluegrassBlock;
import net.mcreator.minecraftmod.block.BlueGrassDirtBlock;
import net.mcreator.minecraftmod.MinecraftmodModElements;
import net.mcreator.minecraftmod.MinecraftmodMod;

import java.util.Map;

@MinecraftmodModElements.ModElement.Tag
public class ChangingBlueGrasstoDirtProcedure extends MinecraftmodModElements.ModElement {
	public ChangingBlueGrasstoDirtProcedure(MinecraftmodModElements instance) {
		super(instance, 20);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency x for procedure ChangingBlueGrasstoDirt!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency y for procedure ChangingBlueGrasstoDirt!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency z for procedure ChangingBlueGrasstoDirt!");
			return;
		}
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency world for procedure ChangingBlueGrasstoDirt!");
			return;
		}
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		IWorld world = (IWorld) dependencies.get("world");
		if (((world.isAirBlock(new BlockPos((int) x, (int) (y + 1), (int) z)))
				|| (!(world.getBlockState(new BlockPos((int) x, (int) (y + 1), (int) z)).isSolid())))) {
			world.setBlockState(new BlockPos((int) x, (int) y, (int) z), BluegrassBlock.block.getDefaultState(), 3);
		} else {
			world.setBlockState(new BlockPos((int) x, (int) y, (int) z), BlueGrassDirtBlock.block.getDefaultState(), 3);
		}
	}
}
