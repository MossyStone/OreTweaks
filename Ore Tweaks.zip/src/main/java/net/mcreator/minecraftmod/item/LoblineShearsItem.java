
package net.mcreator.minecraftmod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.ShearsItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

import net.mcreator.minecraftmod.itemgroup.LoblineTabItemGroup;
import net.mcreator.minecraftmod.MinecraftmodModElements;

@MinecraftmodModElements.ModElement.Tag
public class LoblineShearsItem extends MinecraftmodModElements.ModElement {
	@ObjectHolder("minecraftmod:lobline_shears")
	public static final Item block = null;
	public LoblineShearsItem(MinecraftmodModElements instance) {
		super(instance, 22);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ShearsItem(new Item.Properties().group(LoblineTabItemGroup.tab).maxDamage(100)) {
			@Override
			public int getItemEnchantability() {
				return 10;
			}

			@Override
			public float getDestroySpeed(ItemStack stack, BlockState block) {
				return 6f;
			}
		}.setRegistryName("lobline_shears"));
	}
}
