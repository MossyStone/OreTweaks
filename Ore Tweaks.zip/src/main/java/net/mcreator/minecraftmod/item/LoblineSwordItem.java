
package net.mcreator.minecraftmod.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.entity.player.PlayerEntity;

import net.mcreator.minecraftmod.procedures.LoblineSwordItemIsCraftedsmeltedProcedure;
import net.mcreator.minecraftmod.itemgroup.LoblineTabItemGroup;
import net.mcreator.minecraftmod.MinecraftmodModElements;

import java.util.Map;
import java.util.HashMap;

@MinecraftmodModElements.ModElement.Tag
public class LoblineSwordItem extends MinecraftmodModElements.ModElement {
	@ObjectHolder("minecraftmod:lobline_sword")
	public static final Item block = null;
	public LoblineSwordItem(MinecraftmodModElements instance) {
		super(instance, 9);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new SwordItem(new IItemTier() {
			public int getMaxUses() {
				return 290;
			}

			public float getEfficiency() {
				return 6f;
			}

			public float getAttackDamage() {
				return 8f;
			}

			public int getHarvestLevel() {
				return 1;
			}

			public int getEnchantability() {
				return 10;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(LoblineItem.block, (int) (1)));
			}
		}, 3, -2.4f, new Item.Properties().group(LoblineTabItemGroup.tab)) {
			@Override
			public void onCreated(ItemStack itemstack, World world, PlayerEntity entity) {
				super.onCreated(itemstack, world, entity);
				double x = entity.getPosX();
				double y = entity.getPosY();
				double z = entity.getPosZ();
				{
					Map<String, Object> $_dependencies = new HashMap<>();
					$_dependencies.put("itemstack", itemstack);
					LoblineSwordItemIsCraftedsmeltedProcedure.executeProcedure($_dependencies);
				}
			}
		}.setRegistryName("lobline_sword"));
	}
}
