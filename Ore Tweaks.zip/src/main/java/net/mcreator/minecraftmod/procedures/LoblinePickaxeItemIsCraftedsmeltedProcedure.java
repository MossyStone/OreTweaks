package net.mcreator.minecraftmod.procedures;

import net.minecraft.item.ItemStack;
import net.minecraft.enchantment.Enchantments;

import net.mcreator.minecraftmod.MinecraftmodModElements;
import net.mcreator.minecraftmod.MinecraftmodMod;

import java.util.Map;

@MinecraftmodModElements.ModElement.Tag
public class LoblinePickaxeItemIsCraftedsmeltedProcedure extends MinecraftmodModElements.ModElement {
	public LoblinePickaxeItemIsCraftedsmeltedProcedure(MinecraftmodModElements instance) {
		super(instance, 37);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			if (!dependencies.containsKey("itemstack"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency itemstack for procedure LoblinePickaxeItemIsCraftedsmelted!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		((itemstack)).addEnchantment(Enchantments.SILK_TOUCH, (int) 10);
	}
}
