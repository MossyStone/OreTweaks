package net.mcreator.minecraftmod.procedures;

import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import net.mcreator.minecraftmod.MinecraftmodModElements;
import net.mcreator.minecraftmod.MinecraftmodMod;

import java.util.Map;

@MinecraftmodModElements.ModElement.Tag
public class PurplecapFoodEatenProcedure extends MinecraftmodModElements.ModElement {
	public PurplecapFoodEatenProcedure(MinecraftmodModElements instance) {
		super(instance, 41);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				MinecraftmodMod.LOGGER.warn("Failed to load dependency entity for procedure PurplecapFoodEaten!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.REGENERATION, (int) 60, (int) 2, (false), (false)));
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).setHealth((float) 20);
	}
}
